PluginInit = {
	defaultOdrivePath = "/usr/local/bin/odrive",
  URL = "https://docs.odrive.com/docs/odrive-cli#section--download-cli-"
}